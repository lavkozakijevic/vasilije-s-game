<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="garden" tilewidth="32" tileheight="32" tilecount="88" columns="8">
 <image source="tileset_garden.png" width="256" height="352"/>
 <tile id="0">
  <properties>
   <property name="name" value="grass_tl"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="name" value="grass_t"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="name" value="grass_tr"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="name" value="grass_t_b"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="name" value="grass_single"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="name" value="grass_inner_nw"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="name" value="grass_inner_ne"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="name" value="dirt_edge_l"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="name" value="grass_long_tl"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="name" value="grass_long_t"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="name" value="grass_long_tr"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="name" value="dirt_edge_r"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="name" value="dirt_l"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="name" value="dirt_c"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="name" value="dirt_r"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="name" value="dirt_bl"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="16">
  <properties>
   <property name="name" value="dirt_b"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="17">
  <properties>
   <property name="name" value="dirt_br"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="18">
  <properties>
   <property name="name" value="tree_blossom_crown_tl"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="19">
  <properties>
   <property name="name" value="tree_blossom_crown_tc"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="20">
  <properties>
   <property name="name" value="tree_blossom_crown_tr"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="21">
  <properties>
   <property name="name" value="tree_blossom_crown_ml"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="22">
  <properties>
   <property name="name" value="tree_blossom_crown_mc"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="23">
  <properties>
   <property name="name" value="tree_blossom_crown_mr"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="24">
  <properties>
   <property name="name" value="tree_blossom_branch_l"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="25">
  <properties>
   <property name="name" value="tree_blossom_branch_m"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="26">
  <properties>
   <property name="name" value="tree_blossom_branch_r"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="27">
  <properties>
   <property name="name" value="tree_blossom_trunk_top"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="28">
  <properties>
   <property name="name" value="tree_blossom_trunk_base"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="29">
  <properties>
   <property name="name" value="tree_walnut_crown_tl"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="30">
  <properties>
   <property name="name" value="tree_walnut_crown_tc"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="31">
  <properties>
   <property name="name" value="tree_walnut_crown_tr"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="32">
  <properties>
   <property name="name" value="tree_walnut_crown_ml"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="33">
  <properties>
   <property name="name" value="tree_walnut_crown_mc"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="34">
  <properties>
   <property name="name" value="tree_walnut_crown_mr"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="35">
  <properties>
   <property name="name" value="tree_walnut_branch_l"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="36">
  <properties>
   <property name="name" value="tree_walnut_branch_m"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="37">
  <properties>
   <property name="name" value="tree_walnut_branch_r"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="38">
  <properties>
   <property name="name" value="tree_walnut_trunk_top"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="39">
  <properties>
   <property name="name" value="tree_walnut_trunk_base"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="40">
  <properties>
   <property name="name" value="bench_l"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="41">
  <properties>
   <property name="name" value="bench_r"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="42">
  <properties>
   <property name="name" value="table_l"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="43">
  <properties>
   <property name="name" value="table_r"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="name" value="wheelbarrow_l"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="45">
  <properties>
   <property name="name" value="wheelbarrow_r"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="46">
  <properties>
   <property name="name" value="flowerpots_top"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="47">
  <properties>
   <property name="name" value="flowerpots_base"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="48">
  <properties>
   <property name="name" value="brick_wall_l"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="49">
  <properties>
   <property name="name" value="brick_wall_m"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="name" value="brick_wall_r"/>
   <property name="solid" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="name" value="shed_roof_l"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="52">
  <properties>
   <property name="name" value="shed_roof_m"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="53">
  <properties>
   <property name="name" value="shed_roof_r"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="54">
  <properties>
   <property name="name" value="shed_wall_l"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="55">
  <properties>
   <property name="name" value="shed_door"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="56">
  <properties>
   <property name="name" value="shed_wall_r"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="57">
  <properties>
   <property name="name" value="trampoline_idle"/>
   <property name="bounce" type="bool" value="true"/>
   <property name="bounce_multiplier" type="float" value="2.4"/>
  </properties>
 </tile>
 <tile id="58">
  <properties>
   <property name="name" value="trampoline_0"/>
   <property name="bounce" type="bool" value="true"/>
   <property name="bounce_multiplier" type="float" value="2.4"/>
  </properties>
 </tile>
 <tile id="59">
  <properties>
   <property name="name" value="trampoline_1"/>
   <property name="bounce" type="bool" value="true"/>
   <property name="bounce_multiplier" type="float" value="2.4"/>
  </properties>
 </tile>
 <tile id="60">
  <properties>
   <property name="name" value="trampoline_2"/>
   <property name="bounce" type="bool" value="true"/>
   <property name="bounce_multiplier" type="float" value="2.4"/>
  </properties>
 </tile>
 <tile id="61">
  <properties>
   <property name="name" value="trampoline_3"/>
   <property name="bounce" type="bool" value="true"/>
   <property name="bounce_multiplier" type="float" value="2.4"/>
  </properties>
 </tile>
 <tile id="62">
  <properties>
   <property name="name" value="deco_flowers_a"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="63">
  <properties>
   <property name="name" value="deco_flowers_b"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="64">
  <properties>
   <property name="name" value="deco_tulips"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="65">
  <properties>
   <property name="name" value="deco_watering_can"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="66">
  <properties>
   <property name="name" value="deco_hose"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="67">
  <properties>
   <property name="name" value="deco_gnome"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="68">
  <properties>
   <property name="name" value="deco_birdbath_top"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="69">
  <properties>
   <property name="name" value="deco_birdbath_base"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="70">
  <properties>
   <property name="name" value="deco_fence"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="71">
  <properties>
   <property name="name" value="deco_fence_end"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="72">
  <properties>
   <property name="name" value="deco_swing_tl"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="73">
  <properties>
   <property name="name" value="deco_swing_tr"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="74">
  <properties>
   <property name="name" value="deco_swing_bl"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="75">
  <properties>
   <property name="name" value="deco_swing_br"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="76">
  <properties>
   <property name="name" value="back_door_tl"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="77">
  <properties>
   <property name="name" value="back_door_tr"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="78">
  <properties>
   <property name="name" value="back_door_ml"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="79">
  <properties>
   <property name="name" value="back_door_mr"/>
   <property name="decor" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="80">
  <properties>
   <property name="name" value="back_door_bl"/>
   <property name="decor" type="bool" value="true"/>
   <property name="level_start" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="81">
  <properties>
   <property name="name" value="back_door_br"/>
   <property name="decor" type="bool" value="true"/>
   <property name="level_start" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
