<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="house_night" tilewidth="32" tileheight="32" tilecount="24" columns="8">
 <image source="tileset_house_night.png" width="256" height="96"/>
 <tile id="0">
  <properties>
   <property name="name" value="tablecloth_tl"/>
   <property name="hide" type="bool" value="true"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="name" value="tablecloth_tr"/>
   <property name="hide" type="bool" value="true"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="name" value="tablecloth_bl"/>
   <property name="hide" type="bool" value="true"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="name" value="tablecloth_br"/>
   <property name="hide" type="bool" value="true"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="name" value="heavy_curtain_top"/>
   <property name="hide" type="bool" value="true"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="name" value="heavy_curtain_mid"/>
   <property name="hide" type="bool" value="true"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="name" value="heavy_curtain_bottom"/>
   <property name="hide" type="bool" value="true"/>
   <property name="foreground" type="bool" value="true"/>
   <property name="fade_when_behind" type="bool" value="true"/>
   <property name="fade_alpha_note" value="engine fades the whole layer to ~35% while the hero overlaps"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="name" value="armchair_blanket_tl"/>
   <property name="hide" type="bool" value="true"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="name" value="armchair_blanket_tr"/>
   <property name="hide" type="bool" value="true"/>
   <property name="oneway" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="name" value="armchair_blanket_bl"/>
   <property name="hide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="name" value="armchair_blanket_br"/>
   <property name="hide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="name" value="laundry_basket"/>
   <property name="hide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="name" value="cushion_pile_l"/>
   <property name="hide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="name" value="cushion_pile_r"/>
   <property name="hide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="name" value="coat_rack_top"/>
   <property name="hide" type="bool" value="true"/>
   <property name="foreground" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="name" value="coat_rack_mid"/>
   <property name="hide" type="bool" value="true"/>
   <property name="foreground" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="16">
  <properties>
   <property name="name" value="coat_rack_bottom"/>
   <property name="hide" type="bool" value="true"/>
   <property name="foreground" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
